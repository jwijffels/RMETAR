library(testthat)
test_package("RMETAR")
